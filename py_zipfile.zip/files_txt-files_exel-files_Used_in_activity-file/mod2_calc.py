def addition(a,b):
      return (a+b)

def subtraction(a,b):
      return (a-b)

def multiplication(a,b):
      return (a*b)

def division(a,b):

      if b==0:
         return ("Division is not possible")
      else:
         return (a/b)
